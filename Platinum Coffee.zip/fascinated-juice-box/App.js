
import { StyleSheet, Text, View, Image, ScrollView } from 'react-native';

export default function App() {
  return (
    <View style={styles.container}>
        <View style={styles.divider1}>
        <Image
            style={{
              height: 50,
              width: 60,    
              position: 'absolute',
              right: 260,
              top: 30,
              bottom: 0,          
            }} 
            source={require("./assets/greentea.png")}/>
          <Text
            style={{
                position: 'absolute',
                top: 6,
                left: 80,
                fontSize: 22,
              }}            
          ><i>Green Tea</i></Text>
          <Text
            style={{
              position: 'absolute',
              left: 80,
              right: 5,
              top: 35,
              bottom: 0,
              textAlign: 'justify',
              fontSize: '13px',
            }}
            >Green Tea. Blended with mint,
    lemongrass and lemon verbena, then sweetened just right and given a good shake with ice, so-refreshing!</Text>
        </View>
        <View style={styles.divider2}>
        <Image
            style={{
              height: 50,
              width: 60,    
              position: 'absolute',
              right: 260,
              top: 30,
              bottom: 0,          
            }} 
            source={require("./assets/late.png")}/>
             <Text
            style={{
                position: 'absolute',
                top: 6,
                left: 80,
                fontSize: 22,
              }}            
          ><i>Latte</i></Text>
          <Text
            style={{
              position: 'absolute',
              left: 80,
              right: 5,
              top: 30,
              bottom: 0,
              textAlign: 'justify',
              fontSize: '13px',
            }}
            >A neat twist that can be done with any of the new Teavana teas is called a tea latte.
    Basically, a tea latte is equal parts hot tea and steamed milk.</Text>
        </View>
        <View style={styles.divider1}>
        <Image
            style={{
              height: 50,
              width: 60,    
              position: 'absolute',
              right: 260,
              top: 20,
              bottom: 0,          
            }} 
            source={require("./assets/orange.png")}/>
             <Text
            style={{
                position: 'absolute',
                top: 6,
                left: 80,
                fontSize: 22,
              }}            
          ><i>Orange Smoothie</i></Text>
          <Text
            style={{
              position: 'absolute',
              left: 80,
              right: 5,
              top: 33,
              bottom: 0,
              textAlign: 'justify',
              fontSize: '13px',
            }}
          >Starbucks Orange Mango Smoothie. A nourishing blend of natural orange mango juice,
    a whole banana, milk, whey protein, and fiber powder and ice.</Text>
        </View>
        <View style={styles.divider2}>
          <Image
            style={{
              height: 50,
              width: 60,    
              position: 'absolute',
              right: 260,
              top: 20,
              bottom: 0,          
            }} 
            source={require("./assets/orangevanilla.png")}/>
             <Text
            style={{
                position: 'absolute',
                top: 6,
                left: 80,
                fontSize: 22,
              }}            
          ><i>Orange Vanilla</i></Text>
          <Text
            style={{
              position: 'absolute',
              left: 80,
              right: 5,
              top: 40,
              bottom: 0,
              textAlign: 'justify',
              fontSize: '13px',
            }}
            >This rich and creamy blend of vanilla bean, milk and ice topped with whipped cream takes va-va-vanilla flavor to another level.</Text>
        </View>
        <View style={styles.divider1}>
        <Image
            style={{
              height: 50,
              width: 60,    
              position: 'absolute',
              right: 260,
              top: 20,
              bottom: 0,          
            }} 
            source={require("./assets/cappcunio.png")}/>
             <Text
            style={{
                position: 'absolute',
                top: 6,
                left: 80,
                fontSize: 22,
              }}            
          ><i>Cappuccino</i></Text>
          <Text
            style={{
              position: 'absolute',
              left: 80,
              right: 5,
              top: 35,
              bottom: 0,
              textAlign: 'justify',
              fontSize: '13px',
            }}
            >By Starbucks definition, a cappuccino made up of shots of espresso, half steamed milk (2% by default,)</Text>
        </View>
        <View style={styles.divider2}>
        <Image
            style={{
              height: 50,
              width: 60,    
              position: 'absolute',
              right: 260,
              top: 20,
              bottom: 0,          
            }} 
            source={require("./assets/thaitea.png")}/>
             <Text
            style={{
                position: 'absolute',
                top: 6,
                left: 80,
                fontSize: 22,
              }}            
          ><i>Thai Tea</i></Text>
          <Text
            style={{
              position: 'absolute',
              left: 80,
              right: 5,
              top: 35,
              bottom: 0,
              textAlign: 'justify',
              fontSize: '13px',
            }}
          >Thai Tea is is made from strongly-brewed black tea, often spiced with ingredients such as star anise,
    crushed tamarind, cardamom</Text>
        </View>
        <View style={styles.divider1}>
        <Image
            style={{
              height: 50,
              width: 60,    
              position: 'absolute',
              right: 260,
              top: 20,
              bottom: 0,          
            }} 
            source={require("./assets/tea.png")}/>
             <Text
            style={{
                position: 'absolute',
                top: 6,
                left: 80,
                fontSize: 22,
              }}            
          ><i>Tea</i></Text>
          <Text
            style={{
              position: 'absolute',
              left: 80,
              right: 5,
              top: 35,
              bottom: 0,
              textAlign: 'justify',
              fontSize: '13px',
            }}
          >Right next to water, tea is hailed as the most consumed drink in the world. Every single drop of tea
    comes from the same type of plant</Text>
        </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },

  divider1: {
    backgroundColor: '#f1f1f1',
    height: '13%',
    width: '99%',
    alignItems: 'center',
    justifyContent: 'center',
  },

  divider2: {
    backgroundColor: '#fff',
    height: '13%',
    width: '99%',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
